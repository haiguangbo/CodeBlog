require('./angular-locale_am');
module.exports = 'ngLocale';
