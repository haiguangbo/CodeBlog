require('./angular-locale_af-za');
module.exports = 'ngLocale';
